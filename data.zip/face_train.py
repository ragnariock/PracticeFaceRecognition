import numpy as np
import os
from PIL import Image as image
import cv2
import pickle


path_to_cascade = "cascade/haarcascade_frontalface_alt2.xml"
face_cascade=cv2.CascadeClassifier(path_to_cascade)

recognizer = cv2.face.LBPHFaceRecognizer_create()

base_dir = os.path.dirname(os.path.abspath(__file__))

data_folder = os.path.join(base_dir,"data")

print("data folder : ", data_folder)

def make_train_datasets():
	current_id = 0
	label_ids={}
	y_labels = []
	x_train = [] 


	for root,dirs,files in os.walk(data_folder):
		for file in files:
			if file.endswith("jpg"):
				path = os.path.join(root,file)
				label = os.path.basename(os.path.dirname(path)).replace(" ","-").lower()
				
				if not label in label_ids:
					label_ids[label]=current_id
					current_id+=1
				id_ = label_ids[label]
				print(label_ids)
				pil_Image=image.open(path).convert("L") # Gray
				image_array=np.array(pil_Image,"uint8")
				faces=face_cascade.detectMultiScale(image_array,scaleFactor=2,minNeighbors=3)
				for (x,y,w,h) in faces:
					roi_gray=image_array[y:y+h,x:x+w]
					x_train.append(roi_gray)
					y_labels.append(id_)

	return x_train,y_labels,label_ids


def write_pkl():
	x,y,label_ids=make_train_datasets()
	with open("labels.pickle","wb") as f:
		pickle.dump(label_ids,f)
	return x,y,label_ids
def train():
	x,y,label = write_pkl()
	recognizer.train(x,np.array(y))
	recognizer.save("trainner.yml")

train()